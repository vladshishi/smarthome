<?php
  require "../includes/includes.php";
  $name = $_POST ["name"];
  $email = $_POST ["email"];
  $text = $_POST ["text"];
  $name = htmlspecialchars($name);
  $email = htmlspecialchars($email);
  $text = htmlspecialchars ($text);
  $name = urldecode($name);
  $email = urldecode($email);
  $text = urldecode ($text);
  $name = trim($name);
  $email = trim($email);
  $text = trim($text);
  $req = mysqli_query ($connection, "INSERT INTO `messages` (`name`, `email`, `text`, `time`) VALUES ('$name', '$email', '$text', current_timestamp())");
  if ($req) :
?>

<!DOCTYPE html>
<html>
<head>
  <?php require "../includes/config.php"?>
</head>
<body>
	<nav class="navbar navbar-expand-md navbar-light bg-light sticky-top top">
	  <div class="container-fluid">
	    <a class="navbar-brand" href="../index.php">
	      <img src="/images/smarthome.svg" alt="Smart Home" width="30" height="24" class="d-inline-block align-text-top">
	      Smart Home
	    </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target=".navbar-collapse" aria-controls="#navbarResponsive" aria-expanded="true">
        <span class="navbar-toggler-icon"></span>
      </button>
		  <div class="collapse navbar-collapse" id="navbarResponsive">
	      <ul class="navbar-nav ml-auto">
	        <li class="nav-item">
	          <a class="nav-link active" aria-current="page" href="../index.php">Главная</a>
	        </li>
	      </ul>
	    </div>
	  </div>
	</nav>
    <center>
        <span>Сообщение успешно отправлено!</span>
    </center>
</body>
</html>

<?php else : ?>

<!DOCTYPE html>
<html>
<head>
  <?php require "../includes/config.php"?>
</head>
<body>
	<nav class="navbar navbar-expand-md navbar-light bg-light sticky-top top">
	  <div class="container-fluid">
	    <a class="navbar-brand" href="../index.php">
	      <img src="/images/smarthome.svg" alt="Smart Home" width="30" height="24" class="d-inline-block align-text-top">
	      Smart Home
	    </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target=".navbar-collapse" aria-controls="#navbarResponsive" aria-expanded="true">
        <span class="navbar-toggler-icon"></span>
      </button>
		  <div class="collapse navbar-collapse" id="navbarResponsive">
	      <ul class="navbar-nav ml-auto">
	        <li class="nav-item">
	          <a class="nav-link active" aria-current="page" href="../index.php">Главная</a>
	        </li>
	      </ul>
	    </div>
	  </div>
	</nav>
    <center>
        <span>Извините, что-то пошло не так... Попробуйте позже</span>
    </center>
</body>
</html>

<?php endif; ?>
