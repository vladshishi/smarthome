<?php require "../includes/includes.php"; ?>
<?php if (!isset ($_SESSION ["logged_user"])) : header ("Location: signin.php"); ?>

<?php else : ?>
<!DOCTYPE html>
<html>
<head>
	<?php require "../includes/config.php" ?>
</head>
<body>
	<nav class="navbar navbar-expand-md navbar-light bg-light sticky-top top">
	  <div class="container-fluid">
	    <a class="navbar-brand" href="../index.php">
	      <img src="/images/smarthome.svg" alt="Smart Home" width="30" height="24" class="d-inline-block align-text-top wow swing">
	      Smart Home
	    </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="../index.php">Главная</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="logout.php">Выйти</a>
                </li>
								<li class="nav-item">
		          	<a class="nav-link active" aria-current="page" href="helpus.php">Помогали</a>
		        </li>
            </ul>
        </div>
	  </div>
	</nav>

    <br />
    <center><h2>Показания прибора</h2></center>
    <br />
    <center>
        <p>temperature - температура, light - освещение, humidity - влажность, ambient_pressure - атмосферное давление, CO - угарный газ, time - время</p>
    </center>
    <br />
    <div class = "table-responsive">
        <table border = 5  bordercolor = "black" class = "table table-bordered">
            <thead class="table-dark">
                <tr>
                    <?php
                        $sql = "SHOW COLUMNS FROM `".$_SESSION['logged_user']."`";
                        $result = mysqli_query ($connection, $sql);
                        while ($row = $result->fetch_assoc()) {
                            echo "<th scope='col'>".$row["Field"]."</th>";
                        }
                    ?>
                </tr>
            </thead>
            <tbody>
                <?php
					$i = 1;
                    $sql = "SELECT * FROM (SELECT * FROM `".$_SESSION['logged_user']."` ORDER BY `id` DESC LIMIT 10) t ORDER BY `id`";
                    $result = mysqli_query ($connection, $sql);
                    while ($row = $result->fetch_assoc()) {
							echo "<tr><td class = 'table-dark'>".$row['id']."</td><td style = 'color: white; background-color: #FF8308'>".$row['temperature']."°C</td><td style = 'background-color: #FFE208'>".$row['light']."%</td><td style = 'background-color: #99FAFF'>".$row['humidity']."%</td><td style = 'color: white; background-color: #ED07D6'>".$row['ambient_pressure']." мм рт. ст.</td><td style = 'color: white; background-color: #C4C4C4'>".$row['CO']."%</td>
	                            <td>".$row['time']."</td></tr>";
					}
                ?>
            </tbody>
        </table>
    </div>
	<center>
		<a href="excel.php"><button type = "button" class="btn btn-outline-success wow fadeIn" style="margin-top: 2%">Скачать данные в виде файла "Excel"</button></a>
	</center>
	<br /><br />
</body>
</html>

<?php endif; ?>
