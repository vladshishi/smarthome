<?php require "../includes/includes.php"; ?>
<?php if (isset ($_SESSION ["logged_user"])) : header ("Location: admin.php"); ?>

<?php else : ?>
<?php
    $number = $_POST["number"];
    $pass = $_POST["pass"];

    $pass_count = mysqli_query($connection, "SELECT `password` FROM `devices` WHERE `number` = '$number'");
    $count = mysqli_query($connection, "SELECT * FROM `devices` WHERE `number` = '$number'");
    $count_2 = mysqli_query($connection, "SELECT `confirmed` FROM `devices` WHERE `number` = '$number'");
    if (password_verify($pass, mysqli_fetch_array($pass_count)[0]) && mysqli_fetch_array($count_2)[0] == "YES" && mysqli_num_rows($count) != 0) {
        $_SESSION ["logged_user"] = $number;
        header("Location: admin.php");
    }
    else if (mysqli_num_rows($count) == 0) {
        header("Location: signin.php?error=Нет в базе данных такого устройства");
    }
    else if (mysqli_fetch_array($count_2)[0] == "NO") {
        header("Location: signin.php?error=Устройство не зарегистрировано");
    }
    else if (password_verify($tc, mysqli_fetch_array($tc_count)[0]) == false) {
        header("Location: signin.php?error=Неправильный пароль");
    }
    else {
        header("Location: signin.php?error=Что-то пошло не так. Попробуйте позже");
    }
?>

<?php endif; ?>
