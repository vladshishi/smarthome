<?php require "../includes/includes.php"; ?>
<?php if (isset ($_SESSION ["admin_logged_user"])) : header ("Location: support.php"); ?>

<?php else : ?>
<?php
    $nick = $_POST["nick"];
    $pass = $_POST["password"];

    $pass_count = mysqli_query($connection, "SELECT `password` FROM `support` WHERE `nick` = '$nick'");
    $count = mysqli_query($connection, "SELECT `nick` FROM `support` WHERE `nick` = '$nick'");

    if (password_verify($pass, mysqli_fetch_array($pass_count)[0]) && mysqli_num_rows($count) != 0) {
        $_SESSION ["admin_logged_user"] = $nick;
        header("Location: support.php");
    }
    else if (mysqli_num_rows($count) == 0) {
        header("Location: signin_admin.php?error=Нет такого админа");
    }
    else if (password_verify($pass, mysqli_fetch_array($pass_count)[0]) == false) {
        header("Location: signin_admin.php?error=Неправильный пароль");
    }
    else {
        header("Location: signin_admin.php?error=Что-то пошло не так. Попробуйте позже");
    }

?>

<?php endif; ?>
