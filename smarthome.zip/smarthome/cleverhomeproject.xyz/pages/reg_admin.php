<?php require "../includes/includes.php"; ?>
<?php if (isset ($_SESSION ["admin_logged_user"])) : header ("Location: support.php"); ?>

<?php else : ?>
<?php

    $nick = $_POST["nick"];
    $pass = $_POST["pass"];

    $pass = password_hash($pass, PASSWORD_DEFAULT);

    $count = mysqli_query($connection, "SELECT * FROM `support` WHERE `nick` = '$nick'");

    if (mysqli_num_rows($count) == 0) {
        mysqli_query($connection, "INSERT INTO `support` (`id`, `nick`, `password`) VALUES (NULL, '$nick', '$pass')");
        $_SESSION ["admin_logged_user"] = $nick;
        header("Location: support.php");
    }
    else if (mysqli_num_rows($count) != 0) {
        header("Location: signup_admin.php?error=Такой админ уже есть!");
    }
    else {
        header("Location: signup_admin.php?error=Что-то пошло не так. Попробуйте позже");
    }

?>

<?php endif; ?>
