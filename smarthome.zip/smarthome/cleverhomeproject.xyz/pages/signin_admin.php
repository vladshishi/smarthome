<?php require "../includes/includes.php"; ?>
<?php if (isset ($_SESSION ["admin_logged_user"])) : header ("Location: support.php"); ?>

<?php else : ?>
<!DOCTYPE html>
<html>
<head>
	<?php require "../includes/config.php" ?>
</head>
<body>
	<nav class="navbar navbar-expand-md navbar-light bg-light sticky-top top">
	  <div class="container-fluid">
	    <a class="navbar-brand" href="../index.php">
	      <img src="/images/smarthome.svg" alt="Smart Home" width="30" height="24" class="d-inline-block align-text-top">
	      Smart Home
	    </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
      </button>
		  <div class="collapse navbar-collapse" id="navbarResponsive">
	      <ul class="navbar-nav ml-auto">
	        <li class="nav-item">
	          <a class="nav-link active" aria-current="page" href="../index.php">Главная</a>
	        </li>
	      </ul>
	    </div>
	  </div>
	</nav>

  <div class="container">
      <div class="row padding">
          <div class="col-12">
              <center>
                  <div style="margin-top: 5%; font-weight: 600; font-size: xx-large; margin-bottom: 3%">
                      <span>Вход в админ-панель</span>
                  </div>
                  <div style="margin-top: 5%; font-weight: 600; font-size: x-large; margin-bottom: 3%; color: red">
                      <span> <?php echo $_GET["error"] ?> </span>
                  </div>
                  <form action="enter_admin.php" method="POST">
                      <div class="col-md-6 col-xl-6 col-12 col-sm-12 col-lg-6">
                          <label for="nick" class="form-label" style="margin-top: 3%">Ник</label>
                          <input type="text" class="form-control" id="nick" name="nick" required>
                      </div>
                      <div class="col-md-6 col-xl-6 col-12 col-sm-12 col-lg-6">
                          <label for="password" class="form-label" style="margin-top: 3%">Пароль</label>
                          <input type="password" class="form-control" id="password" name="password" required>
                      </div>
                      <button type="submit" class="btn btn-primary" style="margin-top: 2%">Войти</button>
                  </form>
              </center>
          </div>
      </div>
  </div>
</body>
</html>

<?php endif; ?>
