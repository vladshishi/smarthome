<?php require "../includes/includes.php"; ?>
<?php if (!isset ($_SESSION ["admin_logged_user"])) : header ("Location: signin_admin.php"); ?>

<?php else : ?>
<?php
    unset ($_SESSION ["admin_logged_user"]);
    header ("Location: signin_admin.php");
?>

<?php endif; ?>
