<?php
	require "../includes/includes.php";

	$result = mysqli_query($connection, "SELECT * FROM `support`");
	$number = mysqli_num_rows($result);
	$array = array();

	while ($row = $result->fetch_assoc()) {
		array_push($array, $row['id']);
	}

	for ($i = 0; $i <= $number; $i++) {
		mysqli_query ($connection, "UPDATE `support` SET `nick` = '".$_POST['nick_'.$array[$i]]."',
														`password` = '".$_POST['pass_'.$array[$i]]."' WHERE `support`.`id` = ".$array[$i]."");
	}

	header('Location: support.php');

?>
