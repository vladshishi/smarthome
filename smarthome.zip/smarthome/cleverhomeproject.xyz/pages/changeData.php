<?php
	require "../includes/includes.php";

	$result = mysqli_query($connection, "SELECT * FROM `devices`");
	$number = mysqli_num_rows($result);
	$array = array();

	while ($row = $result->fetch_assoc()) {
		array_push($array, $row['id']);
	}

	for ($i = 0; $i <= $number; $i++) {
		mysqli_query ($connection, "UPDATE `devices` SET `number` = '".$_POST['number_'.$array[$i]]."',
														`confirmed` = '".$_POST['confirmed_'.$array[$i]]."',
														`password` = '".$_POST['password_'.$array[$i]]."' WHERE `devices`.`id` = ".$array[$i]."");
	}

	header('Location: support.php');

?>
