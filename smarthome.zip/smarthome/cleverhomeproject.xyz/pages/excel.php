<?php require "../includes/includes.php"; ?>
<?php if (!isset ($_SESSION ["logged_user"])) : header ("Location: signin.php"); ?>

<?php else : ?>
<?php
    require "excelphp/PHPExcel.php";

    $number = $_SESSION["logged_user"];
    $count_2 = mysqli_query($connection, "SELECT * FROM `$number`");

    $titles = array(
        array(
            "name" => "Температура (°C)",
            "ceil" => "A"
        ),
        array(
            "name" => "Освещение (%)",
            "ceil" => "B"
        ),
        array(
            "name" => "Влажность (%)",
            "ceil" => "C"
        ),
        array(
            "name" => "Атмосферное давление (мм рт. ст.)",
            "ceil" => "D"
        ),
        array(
            "name" => "CO (%)",
            "ceil" => "E"
        ),
        array(
            "name" => "Время",
            "ceil" => "H"
        )
    );

    $phpexcel = new PHPExcel();

    for ($i=0; $i<count($titles); $i++) {
        $string = $titles[$i]["name"];
        $string = mb_convert_encoding($string, "UTF-8");
        $cellLetter = $titles[$i]["ceil"] . 1;
        $phpexcel->getActiveSheet()->setCellValueExplicit($cellLetter, $string, PHPExcel_Cell_DataType::TYPE_STRING);
    }

    $i = 2;

    while ($row = $count_2->fetch_assoc ()) {
        $string = $row["temperature"];
        $string = mb_convert_encoding($string, "UTF-8");
        $phpexcel->getActiveSheet()->setCellValueExplicit("A$i", $string, PHPExcel_Cell_DataType::TYPE_STRING);
        $string = $row["light"];
        $string = mb_convert_encoding($string, "UTF-8");
        $phpexcel->getActiveSheet()->setCellValueExplicit("B$i", $string, PHPExcel_Cell_DataType::TYPE_STRING);
        $string = $row["humidity"];
        $string = mb_convert_encoding($string, "UTF-8");
        $phpexcel->getActiveSheet()->setCellValueExplicit("C$i", $string, PHPExcel_Cell_DataType::TYPE_STRING);
        $string = $row["ambient_pressure"];
        $string = mb_convert_encoding($string, "UTF-8");
        $phpexcel->getActiveSheet()->setCellValueExplicit("D$i", $string, PHPExcel_Cell_DataType::TYPE_STRING);
        $string = $row["CO"];
        $string = mb_convert_encoding($string, "UTF-8");
        $phpexcel->getActiveSheet()->setCellValueExplicit("E$i", $string, PHPExcel_Cell_DataType::TYPE_STRING);
        $string = $row["time"];
        $phpexcel->getActiveSheet()->setCellValueExplicit("H$i", $string, PHPExcel_Cell_DataType::TYPE_STRING);
        $i++;
    }

    $phpexcel->getActiveSheet()->getColumnDimension("A")->setWidth("25");
    $phpexcel->getActiveSheet()->getColumnDimension("B")->setWidth("25");
    $phpexcel->getActiveSheet()->getColumnDimension("C")->setWidth("25");
    $phpexcel->getActiveSheet()->getColumnDimension("D")->setWidth("35");
    $phpexcel->getActiveSheet()->getColumnDimension("E")->setWidth("25");
    $phpexcel->getActiveSheet()->getColumnDimension("F")->setWidth("25");
    $phpexcel->getActiveSheet()->getColumnDimension("G")->setWidth("35");
    $phpexcel->getActiveSheet()->getColumnDimension("H")->setWidth("25");

    $page = $phpexcel->setActiveSheetIndex();
    $page->setTitle($number);
    $objWriter = PHPExcel_IOFactory::createWriter($phpexcel, "Excel2007");
    $filename = "excel/".$number.".xlsx";
    if(file_exists($filename)) {
        unlink($filename);
    }
    $objWriter->save($filename);
    header("Location: excel/$number.xlsx");
?>

<?php endif; ?>
