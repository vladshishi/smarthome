<?php
    require "../includes/includes.php";
    $number = $_POST["number"];

    $count = "INSERT INTO `devices` (`number`, `password`, `confirmed`) VALUES ('$number', '', 'NO')";

    if(mysqli_query($connection, $count)){
        header("Location: support.php?error_2=Good");
    }
    else {
        header("Location: support.php?error_2=Bad");
    }

?>
