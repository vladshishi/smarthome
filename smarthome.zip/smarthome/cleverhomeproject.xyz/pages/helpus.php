<?php require "../includes/includes.php"; ?>
<!DOCTYPE html>
<html>
<head>
	<?php require "../includes/config.php" ?>
</head>
<body>
	<nav class="navbar navbar-expand-md navbar-light bg-light sticky-top top">
	  <div class="container-fluid">
	    <a class="navbar-brand" href="../index.php">
	      <img src="/images/smarthome.svg" alt="Smart Home" width="30" height="24" class="d-inline-block align-text-top wow swing">
	      Smart Home
	    </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="../index.php">Главная</a>
                </li>
            </ul>
        </div>
	  </div>
	</nav>
    <center>
        <h2 class = "wow fadeIn" style = "margin-bottom: 7%; margin-top: 2%">Те, кто помогал</h2>
    </center>
    <div class = "container wow fadeIn">
      <center>
        <img src = "../images/amperka.png" width = 180 height = 190 />
        <br />
        <a class = "text-center text" target = "_blank" href = "https://amperka.ru/" style = "text-decoration: underline">Амперка</a>
      </center>
    </div>

    <br />
    <hr />
    <br />

    <div class = "container wow fadeIn">
      <center>
        <img src = "../images/howdy.jpg" width = 180 height = 190 />
        <br />
        <a class = "text-center text" target = "_blank" href = "https://howdyho.net/" style = "text-decoration: underline">Хауди хо</a>
        <br />
        <a class = "text-center text" target = "_blank" href = "https://www.youtube.com/c/HowdyhoNet" style = "text-decoration: underline">Его YouTube канал</a>
      </center>
    </div>

    <br />
    <hr />
    <br />

    <div class = "container wow fadeIn">
      <center>
        <img src = "../images/Jeremy.jpg" width = 180 height = 190 />
        <br />
        <a class = "text-center text" target = "_blank" href="https://www.jeremyblum.com/" style = "text-decoration: underline">Джереми Блум</a>
        <br />
        <a class = "text-center text" target = "_blank" href="https://www.youtube.com/channel/UC4KXPjmKwPutGjwFZsEXB5g" style = "text-decoration: underline">Его YouTube канал</a>
      </center>
    </div>

    <br />
    <hr />
    <br />

    <div class = "container wow fadeIn">
      <center>
        <img src = "../images/dudar.jpg" width = 180 height = 190 />
        <br />
        <a class = "text-center text" target = "_blank" href="https://www.youtube.com/user/PlurrimiTube" style = "text-decoration: underline">Гоша Дударь</a>
      </center>
    </div>
</body>
</html>
