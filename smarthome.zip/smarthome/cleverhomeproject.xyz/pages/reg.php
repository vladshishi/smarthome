<?php require "../includes/includes.php"; ?>
<?php if (isset ($_SESSION ["logged_user"])) : header ("Location: admin.php"); ?>

<?php else : ?>
<?php

    $number = $_POST["number"];
    $pass = $_POST["pass"];

    $pass = password_hash($pass, PASSWORD_DEFAULT);

    $count = mysqli_query($connection, "SELECT * FROM `devices` WHERE `number` = '$number'");
    $count_2 = mysqli_query($connection, "SELECT * FROM `devices` WHERE `number` = '$number' AND `confirmed` = 'YES'");

    if (mysqli_num_rows($count) != 0 && mysqli_num_rows($count_2) == 0) {
        mysqli_query($connection, "UPDATE `devices` SET `confirmed` = 'YES' WHERE `devices`.`number` = '$number';");
        mysqli_query($connection, "UPDATE `devices` SET `password` = '$pass' WHERE `devices`.`number` = '$number';");
        mysqli_query($connection, "CREATE TABLE `$number` ( `id` INT(11) NOT NULL AUTO_INCREMENT , `temperature` VARCHAR(255) NULL DEFAULT NULL, `light` VARCHAR(255) NULL DEFAULT NULL, `humidity` VARCHAR(255) NULL DEFAULT NULL, `ambient_pressure` VARCHAR(255) NULL DEFAULT NULL, `CO` VARCHAR(255) NULL DEFAULT NULL, `time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP , PRIMARY KEY (`id`)) ENGINE = InnoDB;");
        $_SESSION ["logged_user"] = $number;
        header("Location: admin.php");
    }
    else if (mysqli_num_rows($count) == 0) {
        header("Location: signup.php?error=Нет в базе данных такого устройства");
    }
    else if (mysqli_num_rows($count_2) != 0) {
        header("Location: signup.php?error=Устройство уже зарегистрировано");
    }
    else {
        header("Location: signup.php?error=Что-то пошло не так. Попробуйте позже");
    }

?>

<?php endif; ?>
