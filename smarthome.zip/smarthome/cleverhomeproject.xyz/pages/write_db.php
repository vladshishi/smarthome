<?php
    require "../includes/includes.php";
    $number = $_GET['number'];
    $temperature = $_GET['temperature'];
    $light = $_GET['light'];
    $humidity = $_GET['humidity'];
    $ambient_pressure = $_GET['ambient_pressure'];
    $CO = $_GET['CO'];
    echo $CO;
    mysqli_query ($connection, "INSERT INTO `$number` (`temperature`, `light`, `humidity`, `ambient_pressure`, `CO`, `time`) VALUES ('$temperature', '$light', '$humidity', '$ambient_pressure', '$CO', current_timestamp())");
?>
