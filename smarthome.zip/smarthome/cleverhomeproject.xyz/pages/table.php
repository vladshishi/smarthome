<?php require "../includes/includes.php"; ?>
<?php if (!isset ($_SESSION ["admin_logged_user"])) : header ("Location: signin_admin.php"); ?>

<?php else : ?>
<!DOCTYPE html>
<html>
<head>
	<?php require "../includes/config.php" ?>
</head>
<body>
	<nav class="navbar navbar-expand-md navbar-light bg-light sticky-top top">
	  <div class="container-fluid">
	    <a class="navbar-brand" href="../index.php">
	      <img src="/images/smarthome.svg" alt="Smart Home" width="30" height="24" class="d-inline-block align-text-top">
	      Smart Home
	    </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="../index.php">Главная</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="logout_admin.php">Выйти</a>
                </li>
								<li class="nav-item">
		          		<a class="nav-link active" aria-current="page" href="helpus.php">Помогали</a>
		        		</li>
            </ul>
        </div>
	  </div>
	</nav>

    <br />
    <center><h2>Показания прибора (<?php echo $_GET['number'] ?>)</h2></center>
    <br />
    <div class = "table-responsive">
        <table border = 5  bordercolor = "black" class = "table table-bordered">
            <thead class="table-dark">
                <tr>
                    <?php
                        $sql = "SHOW COLUMNS FROM `".$_GET['number']."`";
                        $result = mysqli_query ($connection, $sql);
                        while ($row = $result->fetch_assoc ()) {
                            echo "<th scope='col'>".$row["Field"]."</th>";
                        }
                    ?>
                </tr>
            </thead>
            <tbody>
                <?php
					$i = 1;
                    $sql = "SELECT * FROM `".$_GET['number']."`";
                    $result = mysqli_query ($connection, $sql);
                    while ($row = $result->fetch_assoc ()) {
						echo "<tr><td class = 'table-dark'>".$row['id']."</td><td style = 'color: white; background-color: #FF8308'>".$row['temperature']."</td><td style = 'background-color: #FFE208'>".$row['light']."</td><td style = 'background-color: #99FAFF'>".$row['humidity']."</td><td style = 'color: white; background-color: #ED07D6'>".$row['ambient_pressure']."</td><td style = 'color: white; background-color: #C4C4C4'>".$row['CO']."</td>
                        <td>".$row['time']."</td></tr>";
                    }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>

<?php endif; ?>
