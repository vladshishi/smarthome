<?php
  require "../includes/includes.php";
  $rec = $_POST ["rec"];
  $count = mysqli_query($connection, "SELECT `id` FROM `messages` WHERE `id` = '$rec'");
  if (mysqli_num_rows($count) > 0) {
      mysqli_query ($connection, "DELETE FROM `messages` WHERE `id` = $rec");
      header ("Location: support.php");
  }
  else if (mysqli_query($count) == 0) {
      header ("Location: support.php?error=Такого id нет");
  }
  else {
      header ("Location: support.php?error=Что-то пошло не так");
  }
?>
