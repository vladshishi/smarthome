<!DOCTYPE html>
<html>
<head>
    <?php require "../includes/config.php" ?>
</head>
<body>
    <nav class="navbar navbar-expand-md navbar-light bg-light sticky-top top">
	  <div class="container-fluid">
	    <a class="navbar-brand" href="../index.php">
	      <img src="/images/smarthome.svg" alt="Smart Home" width="30" height="24" class="d-inline-block align-text-top wow swing">
	      Smart Home
	    </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target=".navbar-collapse" aria-controls="#navbarResponsive" aria-expanded="true">
        <span class="navbar-toggler-icon"></span>
      </button>
		  <div class="collapse navbar-collapse" id="navbarResponsive">
	      <ul class="navbar-nav ml-auto">
	        <li class="nav-item">
	          <a class="nav-link active" aria-current="page" href="../index.php">Главная</a>
	        </li>
            <li class="nav-item">
	          <a class="nav-link active" aria-current="page" href="helpus.php">Помогали</a>
	        </li>
	      </ul>
	    </div>
	  </div>
	</nav>

    <br /><br />
    <div class = "container-fluid wow fadeIn">
        <div class = "row padding text-center">
            <h2>Регистрация устройства</h2>
            <p align="justify">
                Для регистрации устройства вам нужны номер устройства, код устройства, трехзначный код. Они указаны на коробке под защитным серым слоем. <span style="color: red">Никому, никогда и ни при каких условиях не сообщаете эти данные! Наша компания их с вас не потребует!</span>
            </p>
        </div>
    </div>

    <br />

    <div class = "container-fluid wow fadeIn">
        <div class = "row padding text-center">
            <h2>Тех. поддержка</h2>
            <p align="justify">
                Если у вас возникли вопросы или трудности, прошу оставить заявку. Сделать это можно, перейдя на главную страницу, пролистав до конца. Там вы увидите кнопку "Задать вопрос", после нажатия которой появится окно с формой. Ответ на вашу заявку поступит на указанную почту.
                Или же можете в том самом окне выбрать иной способ обращения: через Telegram, Gmail, Mail.ru.
            </p>
        </div>
    </div>

    <br />

    <div class = "container-fluid wow fadeIn">
        <div class = "row padding text-center">
            <h2>Таблица с данными</h2>
            <p align="justify">
                Вы можете скачать таблцу с данными в виде таблцы "Excel", перейдя в личный кабинет.
            </p>
        </div>
    </div>

    <br />

    <div class = "container-fluid wow fadeIn">
        <div class = "row padding text-center">
            <h2>Потеря номера, кода, 3-хзначного кода устройства</h2>
            <p align="justify">
                Если вы потеряли данные (номер, код, 3-хзначный код) устройства, то можете обратиться к нам (см. пункт "Тех. поддержка"). Мы обязательно напомним их!
            </p>
        </div>
    </div>
</body>
</html>
