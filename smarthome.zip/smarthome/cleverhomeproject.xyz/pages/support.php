<?php require "../includes/includes.php"; ?>
<?php if (!isset ($_SESSION ["admin_logged_user"])) : header ("Location: signin_admin.php"); ?>

<?php else : ?>
<!DOCTYPE html>
<html>
<head>
	<?php require "../includes/config.php" ?>
</head>
<body>
	<nav class="navbar navbar-expand-md navbar-light bg-light sticky-top top">
	  <div class="container-fluid">
	    <a class="navbar-brand" href="../index.php">
	      <img src="/images/smarthome.svg" alt="Smart Home" width="30" height="24" class="d-inline-block align-text-top">
	      Smart Home
	    </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="../index.php">Главная</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="logout_admin.php">Выйти</a>
                </li>
								<li class="nav-item">
		          	<a class="nav-link active" aria-current="page" href="helpus.php">Помогали</a>
		        </li>
            </ul>
        </div>
	  </div>
	</nav>

    <br />

    <center><h2>Таблица обращений</h2></center>
    <br />
    <div class = "table-responsive">
        <table border = 5  bordercolor = "black" class = "table table-bordered">
            <thead class="table-dark">
                <tr>
                    <?php
                        $sql = "SHOW COLUMNS FROM `messages`";
                        $result = mysqli_query ($connection, $sql);
                        while ($row = $result->fetch_assoc ()) {
                            echo "<th scope='col'>".$row["Field"]."</th>";
                        }

                    ?>
                </tr>
            </thead>
            <tbody>
                <?php
                    $sql = "SELECT * FROM `messages`";
                    $result = mysqli_query ($connection, $sql);
                    while ($row = $result->fetch_assoc ()) {
                        echo "<tr><td class = 'table-dark'>".$row['id']."</td><td style = 'color: white; background-color: #FF8308'>".$row['name']."</td><td style = 'background-color: #FFE208'>".$row['email']."</td><td style = 'background-color: #99FAFF'>".$row['text']."</td><td style = 'color: white; background-color: #ED07D6'>".$row['time']."</td></tr>";
                    }
                ?>
            </tbody>
        </table>
    </div>
    <center>
        <form action = "delete_mess.php" method = "POST">
            <div class="col-md-6 col-xl-6 col-12 col-sm-12 col-lg-6">
                <label for="rec" class="form-label" style="margin-top: 3%">Удалить обращение, где id =</label>
                <input type="text" class="form-control" id="rec" name="rec" maxlength=11 required>
                <p style = "color: red"><?php echo $_GET["error"]?></p>
            </div>
            <button class = "btn btn-lg btn-outline-danger" type = "submit" style = "margin-top: 2%;">Удалить</button>
        </form>
    </center>

    <hr />
    <br />
    <br />

    <center><h2>Информация об аккаунтах пользователей</h2></center>
    <br />
    <div class = "table-responsive">
        <form action = "changeData.php" method = "POST">
            <table border = 5  bordercolor = "black" class = "table table-bordered">
                <thead class="table-dark">
                    <tr>
                        <?php
                            $sql = "SHOW COLUMNS FROM `devices`";
                            $result = mysqli_query ($connection, $sql);
                            while ($row = $result->fetch_assoc ()) {
                                echo "<th scope='col'>".$row["Field"]."</th>";
                            }

                        ?>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $sql = "SELECT * FROM `devices`";
                        $result = mysqli_query ($connection, $sql);
                        while ($row = $result->fetch_assoc ()) {
                            echo "<tr><td>".$row['id']."</td><td><input type = 'text' name = 'number_".$row['id']."' value = '".$row['number']."' /></td><td><input type = 'text' name = 'pass_".$row['id']."' value = '".$row['password']."' /></td><td><input type = 'text' name = 'confirmed_".$row['id']."' value = '".$row['confirmed']."' /></td></tr>";
                        }
                    ?>
                </tbody>
            </table>
            <center>
                <button class = "btn btn-lg btn-outline-warning" type = "submit" style = "margin-top: 2%;">Изменить</button>
            </center>
        </form>
    </div>

	<hr />
	<br />
    <br />
    
    <center><h2>Удалить аккаунт</h2></center>
	<div class="container">
        <div class="row padding">
            <div class="col-12">
                <center>
                    <div class = "wow fadeIn" style="font-weight: 600; font-size: x-large; margin-bottom: 3%; color: red">
                        <span> <?php echo $_GET["error_3"] ?> </span>
                    </div>
                    <form action="delete_acc.php" method="POST">
                        <div class="col-md-6 col-xl-6 col-12 col-sm-12 col-lg-6">
                            <label for="acc" class="form-label wow fadeIn" style="margin-top: 3%">Id аккаунта</label>
                            <input type="text" class="form-control wow fadeIn" id="acc" name="acc" required>
                        </div>
                        <button type="submit" class="btn btn-danger wow fadeIn" style="margin-top: 2%">Удалить</button>
                    </form>
                </center>
            </div>
        </div>
    </div>
    
    <hr />
	<br />
    <br />
    
    <center><h2>Информация об аккаунтах админов</h2></center>
    <br />
    <div class = "table-responsive">
        <form action = "changeDataAdmin.php" method = "POST">
            <table border = 5  bordercolor = "black" class = "table table-bordered">
                <thead class="table-dark">
                    <tr>
                        <?php
                            $sql = "SHOW COLUMNS FROM `support`";
                            $result = mysqli_query ($connection, $sql);
                            while ($row = $result->fetch_assoc ()) {
                                echo "<th scope='col'>".$row["Field"]."</th>";
                            }

                        ?>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $sql = "SELECT * FROM `support`";
                        $result = mysqli_query ($connection, $sql);
                        while ($row = $result->fetch_assoc ()) {
                            echo "<tr><td>".$row['id']."</td><td><input type = 'text' name = 'nick_".$row['id']."' value = '".$row['nick']."' /></td><td><input type = 'text' name = 'pass_".$row['id']."' value = '".$row['password']."' /></td></tr>";
                        }
                    ?>
                </tbody>
            </table>
            <center>
                <button class = "btn btn-lg btn-outline-warning" type = "submit" style = "margin-top: 2%;">Изменить</button>
            </center>
        </form>
    </div>

	<hr />
	<br />
    <br />
    
    <center><h2>Удалить админа</h2></center>
	<div class="container">
        <div class="row padding">
            <div class="col-12">
                <center>
                    <div class = "wow fadeIn" style="font-weight: 600; font-size: x-large; margin-bottom: 3%; color: red">
                        <span> <?php echo $_GET["error_3"] ?> </span>
                    </div>
                    <form action="delete_admin.php" method="POST">
                        <div class="col-md-6 col-xl-6 col-12 col-sm-12 col-lg-6">
                            <label for="id_acc" class="form-label wow fadeIn" style="margin-top: 3%">Id админа</label>
                            <input type="text" class="form-control wow fadeIn" id="id_acc" name="id_acc" required>
                        </div>
                        <button type="submit" class="btn btn-danger wow fadeIn" style="margin-top: 2%">Удалить</button>
                    </form>
                </center>
            </div>
        </div>
    </div>
    
    <hr />
	<br />
    <br />

    <center><h2>Добавить устройство</h2></center>
	<div class="container">
        <div class="row padding">
            <div class="col-12">
                <center>
                    <div class = "wow fadeIn" style="font-weight: 600; font-size: x-large; margin-bottom: 3%; color: red">
                        <span> <?php echo $_GET["error_2"] ?> </span>
                    </div>
                    <form action="plus.php" method="POST">
                        <div class="col-md-6 col-xl-6 col-12 col-sm-12 col-lg-6">
                            <label for="number" class="form-label wow fadeIn" style="margin-top: 3%">Номер устройства (10 символов)</label>
                            <input type="text" class="form-control wow fadeIn" id="number" name="number" maxlength=10 required>
                        </div>
                        <button type="submit" class="btn btn-primary wow fadeIn" style="margin-top: 2%">Добавить</button>
                    </form>
                </center>
            </div>
        </div>
    </div>
    
	<hr />
	<br />
    <br />
	
	<center><h2>Таблицы приборов</h2></center>
    <div class = "container-fluid">
        <div class="list-group">
            <?php
              $sql = "SELECT table_name FROM information_schema.tables WHERE table_schema = 'u1665877_default'";
              $result = mysqli_query($connection, $sql);
              while ($row = $result->fetch_assoc ()) {
								if ($row['table_name'] != "support" && $row['table_name'] != "devices" && $row['table_name'] != "messages"){
										echo "<a href='table.php?number=".$row['table_name']."' class='list-group-item list-group-item-action'>".$row['table_name']."</a>";
								}
								else continue;
              }
            ?>
        </div>
    </div>
    
    <br />
    <br />
    <br />

</body>
</html>

<?php endif; ?>
