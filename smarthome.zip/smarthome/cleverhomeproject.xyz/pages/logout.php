<?php require "../includes/includes.php"; ?>
<?php if (!isset ($_SESSION ["logged_user"])) : header ("Location: signin.php"); ?>

<?php else : ?>
<?php
    unset ($_SESSION ["logged_user"]);
    header ("Location: signin.php");
?>

<?php endif; ?>