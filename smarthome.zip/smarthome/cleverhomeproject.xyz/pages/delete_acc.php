<?php
  require "../includes/includes.php";
  $rec = $_POST ["acc"];
  $count = mysqli_query($connection, "SELECT `id` FROM `devices` WHERE `id` = '$rec'");
  if (mysqli_num_rows($count) > 0) {
      mysqli_query ($connection, "DELETE FROM `devices` WHERE `id` = $rec");
      header ("Location: support.php");
  }
  else if (mysqli_query($count) == 0) {
      header ("Location: support.php?error_3=Такого id нет");
  }
  else {
      header ("Location: support.php?error_3=Что-то пошло не так");
  }
?>
