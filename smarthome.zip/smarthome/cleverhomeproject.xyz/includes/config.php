<title>Smart Home</title>
    <meta charset="utf-8"/>
    <meta name = "viewport" content = "width = device-width, initial-scale = 1.0" />
    <link rel = "shortcut icon" href = "/images/smarthome.svg" type = "image/x-icon">
    <link rel = "stylesheet" href = "/css/bootstrap.css" />
    <link rel = "stylesheet" href = "/css/bootstrap.min.css" />
    <link rel = "stylesheet" href = "/css/bootstrap.rtl.css" />
    <link rel = "stylesheet" href = "/css/bootstrap.rtl.min.css" />
    <link rel = "stylesheet" href = "/css/bootstrap-grid.css" />
    <link rel = "stylesheet" href = "/css/bootstrap-grid.min.css" />
    <link rel = "stylesheet" href = "/css/animate.css" />
    <link rel = "stylesheet" href = "/css/style.css" />
    <style>
        hr {
	        border: 0;
            height: 1px;
            background: #000;
            background-image: -webkit-linear-gradient(left, #fff, #000, #fff);
            background-image: -moz-linear-gradient(left, #fff, #000, #fff);
            background-image: -ms-linear-gradient(left, #fff, #000, #fff);
            background-image: -o-linear-gradient(left, #fff, #000, #fff);
        }

        .text {
            font-size: x-large;
            color: black !important;
        }

        a .text {
            text-decoration: underline;
            color: #5594fa;
        }
        .icons {
            margin-right: 3%;
        }
    </style>
    <script src = "/js/bootstrap.bundle.js"></script>
    <script src = "/js/bootstrap.bundle.min.js"></script>
    <script src = "/js/bootstrap.esm.js"></script>
    <script src = "/js/bootstrap.esm.min.js"></script>
    <script src = "/js/bootstrap.js"></script>
    <script src = "/js/bootstrap.min.js"></script>
    <script src = "/js/wow.min.js"></script>
    <script src = "/js/wow.js"></script>
    <script type = "text/javascript"> new WOW().init(); </script>
    <script type = "text/javascript">
        $(document).ready(function() {
        var margin = 1;
        $("a").click(function() {
            $("html, body").animate({
            scrollTop: $($(this).attr("href")).offset().top+margin+ "px"
            }, {
            duration: 1000,
            easing: "swing"
            });
            return false;
        });
        });

        $('#myModal').on('shown.bs.modal', function () {
        $('#myInput').trigger('focus')
        })
    </script>
