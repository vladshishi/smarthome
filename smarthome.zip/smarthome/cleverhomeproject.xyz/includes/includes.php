<?php
  header('Content-Type: text/html; charset=utf-8');
  $connection = mysqli_connect ("localhost", "u1665877_default", "6E69GXgPt7hdVltk", "u1665877_default");
  if ($connection == false) {
      echo mysqli_connect_error();
      exit();
  }
  session_start ();
?>
